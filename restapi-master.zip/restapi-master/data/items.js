 // Example of a sample items array
export let items = [
  {
    id: 1,
    name: "Apple",
    description: "A fresh red apple",
    price: 0.99,
    inStock: true
  },
  {
    id: 2,
    name: "Banana",
    description: "A ripe banana",
    price: 0.59,
    inStock: true
  },
  {
    id: 3,
    name: "Orange",
    description: "A juicy orange",
    price: 0.79,
    inStock: false
  }
];